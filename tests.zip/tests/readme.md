to create a venv five to setup the isolated virtual environment to run the python tests
python -m venv venv

activate the virtual environment for python
venv/Scripts/activate

install the pytest

   pip install pytest

not setup the playwright
pip install pytest-playwright

install playwright
pip install playwright

install the playwright browsers
playwright install
